CREATE MATERIALIZED VIEW message_data_view AS SELECT u.login,
    m.message,
    a.file_path
   FROM ((message m
     LEFT JOIN attachment a ON ((a.message_message_id = m.message_id)))
     RIGHT JOIN users u ON ((m.user_user_id = u.user_id)));
